import { getStore } from '@netlify/blobs';
import { createGame, makePlayer, assignTeam, startRound, finishRound, nextRound, radiusAt, awardObjective, applyDamage, applyAbility, reviveTeammate, MAX_PLAYERS } from '../../shared/game-logic.js';

const rooms = getStore({ name: 'rift-royale-rooms', consistency: 'strong' });
const json = (body, status = 200) => new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' } });
const cleanCode = (v) => String(v || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6);
const roomKey = (code) => `room-${cleanCode(code)}`;
const makeCode = () => Math.random().toString(36).slice(2, 8).toUpperCase().padEnd(6, 'X');

async function readRoom(code) {
  const entry = await rooms.getWithMetadata(roomKey(code), { consistency: 'strong', type: 'json' });
  if (!entry) throw Object.assign(new Error('Room not found. Check the code or create a new room.'), { status: 404 });
  const game = entry.data; const now = Date.now(); for (const p of game.players || []) { const elapsed = (now - (p.lastAbilityAt || 0)) / 1000; p.abilityCooldown = Math.max(0, 8 - elapsed); p.abilityReady = elapsed >= 8; } return { game, etag: entry.etag };
}
async function mutateRoom(code, fn) {
  // Compare-and-swap prevents stale room snapshots from overwriting a newer update.
  // This is a small-room prototype; high-frequency authoritative simulation should move to a dedicated realtime game server.
  for (let attempt = 0; attempt < 5; attempt++) {
    const { game, etag } = await readRoom(code);
    const result = await fn(game);
    game.updatedAt = Date.now(); game.version = (game.version || 0) + 1;
    const write = await rooms.setJSON(roomKey(code), game, { onlyIfMatch: etag });
    if (write.modified) return { game, result };
  }
  throw Object.assign(new Error('Room changed too quickly. Please retry your action.'), { status: 409 });
}
function requirePlayer(game, playerId) {
  const player = game.players.find(p => p.id === playerId);
  if (!player) throw Object.assign(new Error('You are not a member of this room.'), { status: 403 });
  return player;
}
function checkPlaying(game) { if (game.phase !== 'playing') throw new Error('The match is not currently in progress.'); }
function maybeFinish(game, now) {
  game.stormRadius = radiusAt(game, now);
  // Storm damages exposed players and accelerates the endgame.
  if (game.stormStartedAt && now >= game.stormStartedAt) {
    for (const p of game.players) if (p.alive && p.downed && now > (p.downedUntil || 0)) { p.alive = false; p.downed = false; p.health = 0; }
    for (const p of game.players) if (p.alive && !p.downed && Math.hypot(p.x,p.z) > game.stormRadius) {
      p.health = Math.max(0, p.health - 3);
      if (p.health === 0) { p.alive = false; p.downed = false; }
    }
  }
  finishRound(game, now);
}

export default async (req) => {
  if (req.method !== 'POST') return json({ error: 'Use POST for game actions.' }, 405);
  let body; try { body = await req.json(); } catch { return json({ error: 'Request body must be valid JSON.' }, 400); }
  const action = String(body.action || ''); const playerId = String(body.playerId || ''); const code = cleanCode(body.code);
  try {
    if (action === 'create') {
      if (!playerId) throw new Error('A player identity is required. Refresh the page and try again.');
      const name = String(body.name || 'RiftRunner').trim().slice(0,18) || 'RiftRunner';
      let game, created = false;
      for (let i=0;i<8;i++) {
        const newCode = makeCode();
        const player = makePlayer({ id: playerId, name, hero: body.hero, team: 0 });
        const candidate = createGame(newCode, player, body.mode);
        const result = await rooms.setJSON(roomKey(newCode), candidate, { onlyIfNew: true });
        if (result.modified) { game=candidate; created=true; break; }
      }
      if (!created) throw new Error('Could not reserve a room code. Please try again.');
      return json({ game });
    }
    if (!code) return json({ error: 'A valid six-character room code is required.' }, 400);
    if (action === 'join') {
      const { game } = await mutateRoom(code, g => {
        if (g.phase !== 'lobby') throw new Error('This match has already started.');
        if (g.players.some(p=>p.id===playerId)) return;
        if (g.players.length >= MAX_PLAYERS) throw new Error('This room is full (8 players maximum).');
        const team = assignTeam(g); g.players.push(makePlayer({ id:playerId, name:String(body.name||'RiftRunner').trim().slice(0,18), hero:body.hero, team }));
      });
      return json({ game });
    }
    if (action === 'state') {
      const { game } = await readRoom(code);
      if (playerId && !game.players.some(p=>p.id===playerId)) throw Object.assign(new Error('You are not a member of this room.'), {status:403});
      if (game.phase==='playing') {
        const now = Date.now(); const changed = game.stormRadius !== radiusAt(game,now) || game.players.some(p=>p.downed && now > (p.downedUntil || 0));
        if (changed) { await mutateRoom(code, g => maybeFinish(g,Date.now())); return json({ game:(await readRoom(code)).game }); }
      }
      return json({ game });
    }
    const { game } = await mutateRoom(code, g => {
      const player = requirePlayer(g, playerId); const now=Date.now();
      if (action === 'leave') {
        if (g.phase==='playing') { player.alive=false; player.health=0; maybeFinish(g,now); }
        else { g.players=g.players.filter(p=>p.id!==playerId); if(g.hostId===playerId&&g.players.length)g.hostId=g.players[0].id; }
      } else if (action === 'start') {
        if (g.hostId!==playerId) throw new Error('Only the room host can start the match.');
        if (g.phase==='playing') throw new Error('The match is already in progress.');
        if (g.phase==='round_end') throw new Error('Use Next Round to continue this match.');
        if (g.phase==='finished') { g.round=1;g.rounds=[];g.players.forEach(p=>{p.score=0;p.kills=0;p.assists=0;p.revives=0;}); }
        startRound(g,now);
      } else if (action === 'move') {
        checkPlaying(g); if (!player.alive) throw new Error('Eliminated players cannot move.');
        const x=Number(body.x),z=Number(body.z); if(!Number.isFinite(x)||!Number.isFinite(z))throw new Error('Invalid movement coordinates.');
        const dt=Math.max(.04,Math.min(1.2,(now-player.lastMoveAt)/1000)); const maxDistance=7*dt+1.25;
        const distance=Math.hypot(x-player.x,z-player.z); if(distance>maxDistance)throw new Error('Movement rejected: move speed exceeded.');
        player.x=Math.max(-25,Math.min(25,x));player.z=Math.max(-25,Math.min(25,z));player.rotation=Number.isFinite(Number(body.rotation))?Number(body.rotation):0;player.lastMoveAt=now;player.lastSeenAt=now;
        maybeFinish(g,now);
      } else if (action === 'attack') {
        checkPlaying(g); if (!body.targetId) throw new Error('No opponent selected.'); applyDamage(g,playerId,String(body.targetId),now); maybeFinish(g,now);
      } else if (action === 'revive') {
        checkPlaying(g); reviveTeammate(g,playerId,String(body.targetId||''),now); maybeFinish(g,now);
      } else if (action === 'ability') {
        checkPlaying(g); applyAbility(player,now);
      } else if (action === 'objective') {
        checkPlaying(g); if(Math.hypot(player.x,player.z)>4.5)throw new Error('Move close to the glowing central Rift to claim this objective.'); awardObjective(player);
      } else if (action === 'nextRound') {
        if(g.hostId!==playerId)throw new Error('Only the room host can advance the round.');
        if(g.phase==='round_end')nextRound(g,now);
        else if(g.phase==='finished'){g.round=1;g.rounds=[];g.players.forEach(p=>{p.score=0;p.kills=0;p.assists=0;p.revives=0;});startRound(g,now);}
        else throw new Error('The round has not ended yet.');
      } else throw Object.assign(new Error('Unknown game action.'),{status:400});
    });
    return json({ game });
  } catch (error) { return json({ error: error.message || 'Game action failed.' }, error.status || 400); }
};
