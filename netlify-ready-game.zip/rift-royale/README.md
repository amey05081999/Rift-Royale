# Rift Royale — Battle of the Realms

A browser-based 3D third-person multiplayer battle-arena prototype. It includes solo and squad rooms, hero selection, movement, attacks, abilities, a central Rift objective, a shrinking storm, round scoring, and a three-round champion flow.

## Controls
- **WASD / arrow keys:** move
- **Mouse click / FIRE:** attack the nearest eligible opponent in range
- **Q / ABILITY:** activate the selected hero's defensive/mobility ability
- **E / RIFT:** claim the objective while near the glowing central Rift (+50 points)
- **Phone:** use the on-screen joystick and buttons

## Rules
- Rooms support 2–8 players. A room host starts a match.
- Each match contains three rounds. Eliminations score 100 points, a Rift objective scores 50, and round victory scores 150.
- Solo: last surviving player wins. Squads: last surviving team wins; friendly fire is disabled.
- The Rift Storm begins after 20 seconds and shrinks the safe radius every 15 seconds. Players outside the safe zone take damage.
- At the end of round three, cumulative score decides the champion; round wins and eliminations break ties.

## Development
Requires Node.js 20+.

```sh
npm install
npm run dev
```

## Netlify deployment
This repository uses Vite for the frontend and a Netlify Function at `netlify/functions/game.ts`. The frontend calls `/.netlify/functions/game` directly. The function stores rooms in Netlify Blobs with strong consistency and conditional writes. Upload the ZIP through Netlify Drop or deploy the project through Netlify's supported workflow.

**Prototype limitation:** Netlify Functions + Blobs polling are suitable for a small-room proof of concept, not a high-frequency competitive shooter. Blobs are not a transactional game database, and this implementation uses polling-based synchronization rather than WebSockets. Before public competitive use, move authoritative simulation to a dedicated realtime game server and transactional storage, add identity/rate limiting, and test under concurrent load.

## Tests
`npm test` runs core game-rule tests for scoring, elimination, team fire restrictions, round progression, and champion selection.
