import test from 'node:test';
import assert from 'node:assert/strict';
import { createGame, makePlayer, startRound, awardObjective, applyDamage, nextRound, finishRound, reviveTeammate } from '../shared/game-logic.js';
const setup=(mode='solo')=>{const a=makePlayer({id:'a',name:'Alpha',hero:'Vanguard',team:0,now:1000});const g=createGame('ABC123',a,mode,1000);g.players.push(makePlayer({id:'b',name:'Bravo',hero:'Ranger',team:mode==='teams'?1:1,now:1000}));return g;};
test('starts a match with two players and resets round health',()=>{const g=setup();startRound(g,1000);assert.equal(g.phase,'playing');assert.equal(g.players.length,2);assert.ok(g.players.every(p=>p.health===100&&p.alive));});
test('objective awards 50 points exactly once',()=>{const g=setup();const p=g.players[0];awardObjective(p);assert.equal(p.score,50);assert.throws(()=>awardObjective(p),/already secured/);});
test('valid attack scores elimination points and rejects teammates',()=>{const g=setup();startRound(g,1000);g.players[0].x=0;g.players[0].z=0;g.players[1].x=1;g.players[1].z=0;let now=2000;applyDamage(g,'a','b',now);applyDamage(g,'a','b',now+400);applyDamage(g,'a','b',now+800);applyDamage(g,'a','b',now+1200);assert.equal(g.players[1].alive,false);assert.equal(g.players[0].score,100);const team=setup('teams');startRound(team,1000);team.players[1].team=team.players[0].team;assert.throws(()=>applyDamage(team,'a','b',2000),/teammate/);});
test('three rounds determine cumulative champion',()=>{const g=setup();startRound(g,1000);g.players[1].alive=false;finishRound(g,2000);assert.equal(g.phase,'round_end');nextRound(g,3000);assert.equal(g.round,2);g.players[1].alive=false;finishRound(g,4000);nextRound(g,5000);g.players[1].alive=false;finishRound(g,6000);nextRound(g,7000);assert.equal(g.phase,'finished');assert.equal(g.championId,'a');assert.equal(g.rounds.length,3);});
test('round ends on timeout and picks a survivor by health then kills',()=>{const g=setup();startRound(g,1000);g.players[0].health=70;g.players[1].health=45;finishRound(g,1000+301000);assert.equal(g.phase,'round_end');assert.equal(g.rounds[0].winnerId,'a');});

test('squad round victory awards every winning teammate',()=>{const g=setup('teams');startRound(g,1000);g.players[0].team=0;g.players[1].team=1;g.players[1].alive=false;finishRound(g,2000);assert.equal(g.players[0].score,150);assert.equal(g.rounds[0].winnerId,'a');});
test('revive restores a downed teammate and awards 30 points',()=>{const g=setup('teams');startRound(g,1000);g.players[0].team=0;g.players[1].team=0;g.players[0].x=0;g.players[0].z=0;g.players[1].x=1;g.players[1].z=0;g.players[1].downed=true;g.players[1].downedUntil=15000;g.players[1].health=1;reviveTeammate(g,'a','b',2000);assert.equal(g.players[1].downed,false);assert.equal(g.players[1].health,40);assert.equal(g.players[0].score,30);});

test('storm damage uses elapsed time, not request frequency',async()=>{
  const {tickGame}=await import('../shared/game-logic.js');
  const a=setup(),b=setup();startRound(a,1000);startRound(b,1000);
  for(const g of [a,b]){g.players[0].x=24;g.players[0].z=24;g.players[1].x=0;g.players[1].z=0;g.lastTickAt=21000;}
  tickGame(a,23000);for(let t=21200;t<=23000;t+=200)tickGame(b,t);
  assert.ok(Math.abs(a.players[0].health-b.players[0].health)<1e-8);
  assert.equal(a.players[0].health,88);
});
test('no survivors ends the round immediately',()=>{const g=setup();startRound(g,1000);g.players.forEach(p=>p.alive=false);finishRound(g,2000);assert.equal(g.phase,'round_end');assert.equal(g.rounds[0].winnerId,null);});
test('minimum storm radius does not prematurely select a winner',()=>{const g=setup();startRound(g,1000);g.stormRadius=4;finishRound(g,160000);assert.equal(g.phase,'playing');});
test('downed players cannot attack, claim objectives, or use abilities',async()=>{const {applyAbility}=await import('../shared/game-logic.js');const g=setup('teams');startRound(g,1000);g.players[0].downed=true;assert.throws(()=>applyDamage(g,'a','b',10000));assert.throws(()=>applyAbility(g.players[0],10000));assert.throws(()=>awardObjective(g.players[0]));});
test('practice bots move toward opponents and attack in range',async()=>{const {tickGame}=await import('../shared/game-logic.js');const g=setup();g.players[1].bot=true;startRound(g,1000);const before=g.players[1].x;tickGame(g,2000);assert.ok(g.players[1].x>before);g.players[1].x=g.players[0].x+1;g.players[1].z=g.players[0].z;tickGame(g,3000);assert.ok(g.players[0].health<100);});
test('downed players bleed out before storm activation',async()=>{const {tickGame}=await import('../shared/game-logic.js');const g=setup('teams');startRound(g,1000);g.players[1].downed=true;g.players[1].downedUntil=5000;tickGame(g,6000);assert.equal(g.players[1].alive,false);});
