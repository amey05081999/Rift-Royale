export const MAX_PLAYERS = 8;
export const ROUND_COUNT = 3;
export const ROUND_MS = 5 * 60 * 1000;
export const STORM_START_MS = 20 * 1000;
export const STORM_SHRINK_MS = 15 * 1000;
export const STORM_MIN_RADIUS = 4;
export const HEROES = new Set(['Vanguard', 'Arcanist', 'Ranger']);

export function makePlayer({ id, name, hero = 'Vanguard', team = 0, now = Date.now() }) {
  return { id, name: String(name || 'RiftRunner').slice(0, 18), hero: HEROES.has(hero) ? hero : 'Vanguard', team, x: 0, z: 0, rotation: 0, health: 100, alive: true, downed: false, score: 0, kills: 0, assists: 0, revives: 0, objectiveDone: false, abilityReady: true, abilityCooldown: 0, lastMoveAt: now, lastAttackAt: 0, lastAbilityAt: 0, lastSeenAt: now };
}
export function createGame(code, player, mode = 'solo', now = Date.now()) {
  return { code, mode: mode === 'teams' ? 'teams' : 'solo', hostId: player.id, players: [makePlayer({ ...player, team: 0, now })], phase: 'lobby', round: 1, rounds: [], createdAt: now, startedAt: null, updatedAt: now, stormRadius: 25, stormStartedAt: null, championId: null, championName: null, version: 1 };
}
export function assignTeam(game) {
  if (game.mode !== 'teams') return 0;
  const counts = [0, 0]; game.players.forEach(p => counts[p.team === 1 ? 1 : 0]++);
  return counts[0] <= counts[1] ? 0 : 1;
}
export function startRound(game, now = Date.now()) {
  if (game.players.length < 2) throw new Error('At least two players are required to start a match.');
  if (game.players.length > MAX_PLAYERS) throw new Error('A room can hold at most 8 players.');
  game.phase = 'playing'; game.startedAt = now; game.stormStartedAt = now + STORM_START_MS; game.stormRadius = 25;
  game.players.forEach((p, i) => { const a = (Math.PI * 2 * i) / game.players.length; p.x = Math.cos(a) * 12; p.z = Math.sin(a) * 12; p.health = 100; p.alive = true; p.downed = false; p.objectiveDone = false; p.abilityReady = true; p.abilityCooldown = 0; p.lastMoveAt = now; p.lastAttackAt = 0; p.lastAbilityAt = 0; });
  return game;
}
export function alivePlayers(game) { return game.players.filter(p => p.alive && !p.downed); }
export function radiusAt(game, now = Date.now()) {
  if (!game.stormStartedAt || now < game.stormStartedAt) return 25;
  return Math.max(STORM_MIN_RADIUS, 25 - Math.floor((now - game.stormStartedAt) / STORM_SHRINK_MS) * 2.5);
}
export function finishRound(game, now = Date.now()) {
  if (game.phase !== 'playing') return game;
  const alive = alivePlayers(game); let winner = null;
  if (game.mode === 'solo') { if (alive.length <= 1) winner = alive[0] || null; }
  else { const teams = [...new Set(alive.map(p => p.team))]; if (teams.length <= 1) winner = alive[0] || null; }
  if (!winner && now < game.startedAt + ROUND_MS && game.stormRadius > STORM_MIN_RADIUS) return game;
  if (!winner && alive.length) winner = [...alive].sort((a,b) => b.health-a.health || b.kills-a.kills || a.id.localeCompare(b.id))[0];
  if (winner) {
    if (game.mode === 'teams') game.players.filter(p => p.team === winner.team).forEach(p => { p.score += 150; });
    else winner.score += 150;
  }
  const round = { number: game.round, winnerId: winner?.id || null, winnerName: winner ? (game.mode === 'teams' ? `Team ${winner.team + 1} · ${winner.name}` : winner.name) : null, endedAt: now, standings: [...game.players].sort((a,b) => b.score-a.score).map(p => ({ id:p.id, name:p.name, score:p.score, kills:p.kills, alive:p.alive })) };
  game.rounds[game.round - 1] = round; game.phase = 'round_end'; game.updatedAt = now; return game;
}
export function nextRound(game, now = Date.now()) {
  if (game.phase !== 'round_end') throw new Error('The current round has not ended.');
  if (game.round >= ROUND_COUNT) {
    const champion = [...game.players].sort((a,b) => b.score-a.score || (game.rounds.filter(r=>r.winnerId===b.id).length - game.rounds.filter(r=>r.winnerId===a.id).length) || b.kills-a.kills)[0];
    game.phase = 'finished'; game.championId = champion?.id || null; game.championName = champion?.name || null; return game;
  }
  game.round += 1; return startRound(game, now);
}
export function awardObjective(player) {
  if (player.objectiveDone) throw new Error('You have already secured this Rift objective this round.');
  player.objectiveDone = true; player.score += 50; return player;
}
export function applyDamage(game, attackerId, targetId, now = Date.now()) {
  const attacker = game.players.find(p=>p.id===attackerId), target = game.players.find(p=>p.id===targetId);
  if (!attacker || !attacker.alive) throw new Error('You cannot attack while eliminated.');
  if (!target || !target.alive || target.id===attackerId) throw new Error('That target is not available.');
  if (game.mode==='teams' && attacker.team===target.team) throw new Error('You cannot attack a teammate.');
  if (Math.hypot(attacker.x-target.x,attacker.z-target.z)>12) throw new Error('Target is out of range. Move closer.');
  if (now - attacker.lastAttackAt < 300) throw new Error('Weapon is reloading.');
  attacker.lastAttackAt = now;
  const damage = attacker.hero==='Arcanist' ? 24 : attacker.hero==='Ranger' ? 30 : 28;
  target.health = Math.max(0,target.health-damage);
  if (target.health===0) {
    if (game.mode === 'teams' && !target.downed) { target.health=1; target.downed=true; target.downedUntil=now+12000; }
    else { target.alive=false; target.downed=false; attacker.kills+=1; attacker.score+=100; }
  } else if (target.downed) { target.alive=false; target.downed=false; target.health=0; attacker.kills+=1; attacker.score+=100; }
  return { attacker, target, damage };
}
export function reviveTeammate(game, reviverId, targetId, now = Date.now()) {
  const reviver = game.players.find(p => p.id === reviverId), target = game.players.find(p => p.id === targetId);
  if (game.mode !== 'teams') throw new Error('Revives are available only in squad mode.');
  if (!reviver || !reviver.alive || reviver.downed) throw new Error('You cannot revive while downed or eliminated.');
  if (!target || !target.alive || !target.downed) throw new Error('That teammate is not waiting for a revive.');
  if (reviver.team !== target.team) throw new Error('You can only revive a teammate.');
  if (now > (target.downedUntil || 0)) { target.alive = false; target.downed = false; target.health = 0; throw new Error('The revive window has expired.'); }
  if (Math.hypot(reviver.x-target.x, reviver.z-target.z) > 3.5) throw new Error('Move closer to your teammate to revive them.');
  target.downed = false; target.health = 40; target.revives = (target.revives || 0); reviver.revives += 1; reviver.score += 30;
  return target;
}

export function applyAbility(player, now = Date.now()) {
  if (!player.alive) throw new Error('Eliminated players cannot use abilities.');
  if (now-player.lastAbilityAt < 8000) throw new Error('Ability is recharging.');
  player.lastAbilityAt=now; player.abilityReady=false; player.abilityCooldown=8;
  if (player.hero==='Arcanist') player.health=Math.min(100,player.health+15);
  else if (player.hero==='Ranger') { player.x=Math.max(-24,Math.min(24,player.x*0.6)); player.z=Math.max(-24,Math.min(24,player.z*0.6)); }
  else player.health=Math.min(100,player.health+10);
  return player;
}
